//5.Parcurgere NS cu while in loc de for

#include<iostream>
#include<limits.h>

int V[100];
int n;
using namespace std;

int main(){
    cout<<"n = ";cin>>n;
    for(int i=1;i<=n;i++){
        cout<<"V["<<i<<"] = ";
        cin>>V[i];}
    int i=1;
    do{ int minim=INT_MAX;
        int top=0;
        for(int j=i;j<=n;j++){
            if(V[j]<minim){
                minim=V[j];
                top=j;}}
        swap(V[i],V[top]);
        i++;}while(i<n);
    cout<<endl<<"Sortate "<<endl;
    for(int i=1;i<=n;i++){
    cout<<V[i]<<" ";}
    return 1;}
