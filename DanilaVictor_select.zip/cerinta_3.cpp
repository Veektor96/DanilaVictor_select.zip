//3.Initializarea minimului cu primul

#include<iostream>
#include<limits.h>

int V[100];
int n;
using namespace std;

int main(){
    cout<<"n=";cin>>n;
    for(int i=1;i<=n;i++){
        cout<<"V["<<i<<"] = ";
        cin>>V[i];}
    for(int i=1;i<=n-1;i++){
        int minim=V[i];
        int top=i;
        for(int j=i+1;j<=n;j++){
           if(V[j]<minim) {
            minim=V[j];
            top=j;}}
        swap(V[i],V[top]);}
    cout<<endl<<"Sortate "<<endl;
    for(int i=1;i<=n;i++){
        cout<<V[i]<<" ";}
    return 1;}
